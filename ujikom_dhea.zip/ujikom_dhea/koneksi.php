<?php
$koneksi = mysqli_connect('localhost', 'root', '','dhea_ujikom');
?>